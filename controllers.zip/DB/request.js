
const mysql = require('mysql');
const config = require('./dbConfig');

require('dotenv').config();

module.exports.request = (query) => new Promise((res, rej) => {
    const connection = mysql.createConnection({
        host: 'localhost',
        user: 'transfo3_liss' ,
        password:  'Troconis1!',
        database:'transfo3_liss' 
    })

    connection.query(query, (error,data,fields)=>{
        if(error) rej(error)

        connection.end((err)=>{
            if(err) rej(err)
            res(data)
        })
    })
})