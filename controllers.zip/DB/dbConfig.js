require('dotenv').config();

module.exports = {
    USER: process.env.USER,
    PASSWORD: process.env.PASSWORD,
    HOST: process.env.HOST,
    DB:process.env.DB
}